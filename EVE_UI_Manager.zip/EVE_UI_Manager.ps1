Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

# --- Funkcia: nájde posledný pripojený USB disk ---
function Get-USBDrive {
    $drives = Get-WmiObject Win32_LogicalDisk | Where-Object { $_.DriveType -eq 2 }
    if ($drives.Count -eq 0) {
        [System.Windows.Forms.MessageBox]::Show("No USB drive detected.", "Error", 'OK', 'Error') | Out-Null
        return $null
    }
    return ($drives | Sort-Object VolumeSerialNumber | Select-Object -Last 1).DeviceID
}

# --- Pôvodná cesta k UI súborom (sú v rovnakom priečinku ako skript) ---
$scriptFolder = Split-Path -Parent $MyInvocation.MyCommand.Definition

# --- BackupUI folder ---
$backupFolder = Join-Path $scriptFolder "BackupUI"

# --- Save Current UI to All ---
function SaveCurrentUIToAll {
    $timestamp = Get-Date -Format "yyyy-MM-dd_HH-mm-ss"
    $backupFolderFull = Join-Path $backupFolder $timestamp
    New-Item -Path $backupFolderFull -ItemType Directory -Force | Out-Null

    $coreUserFiles = Get-ChildItem -Path $scriptFolder -Filter "core_user_*.dat" -File
    $coreCharFiles = Get-ChildItem -Path $scriptFolder -Filter "core_char_*.dat" -File

    foreach ($file in $coreUserFiles + $coreCharFiles) {
        Copy-Item -Path $file.FullName -Destination $backupFolderFull -Force
        # Set new date/time for backup copies
        $backupFile = Join-Path $backupFolderFull $file.Name
        (Get-Item $backupFile).LastWriteTime = Get-Date
        (Get-Item $backupFile).CreationTime = Get-Date
    }

    $latestCoreUser = $coreUserFiles | Sort-Object LastWriteTime -Descending | Select-Object -First 1
    if ($latestCoreUser) {
        foreach ($target in $coreUserFiles | Where-Object { $_.FullName -ne $latestCoreUser.FullName }) {
            Copy-Item -Path $latestCoreUser.FullName -Destination $target.FullName -Force
            # Update timestamp of overwritten file
            (Get-Item $target.FullName).LastWriteTime = Get-Date
            (Get-Item $target.FullName).CreationTime = Get-Date
        }
    }
    $latestCoreChar = $coreCharFiles | Sort-Object LastWriteTime -Descending | Select-Object -First 1
    if ($latestCoreChar) {
        foreach ($target in $coreCharFiles | Where-Object { $_.FullName -ne $latestCoreChar.FullName }) {
            Copy-Item -Path $latestCoreChar.FullName -Destination $target.FullName -Force
            # Update timestamp of overwritten file
            (Get-Item $target.FullName).LastWriteTime = Get-Date
            (Get-Item $target.FullName).CreationTime = Get-Date
        }
    }

    $backupDirs = Get-ChildItem -Path $backupFolder -Directory | Sort-Object LastWriteTime
    $now = Get-Date
    $maxBackups = 20
    $ageLimit = $now.AddDays(-14)

    foreach ($folder in $backupDirs) {
        if ($folder.LastWriteTime -lt $ageLimit) {
            Remove-Item -Path $folder.FullName -Recurse -Force
        }
    }

    $remainingDirs = Get-ChildItem -Path $backupFolder -Directory | Sort-Object LastWriteTime
    if ($remainingDirs.Count -gt $maxBackups) {
        $toDelete = $remainingDirs | Select-Object -First ($remainingDirs.Count - $maxBackups)
        foreach ($folder in $toDelete) {
            Remove-Item -Path $folder.FullName -Recurse -Force
        }
    }

    [System.Windows.Forms.MessageBox]::Show("Current UI saved to local BackupUI folder.", "Success", 'OK', 'Information') | Out-Null
}

# --- Restore from Last Backup ---
function RestoreFromLastBackup {
    if (-not (Test-Path $backupFolder)) {
        [System.Windows.Forms.MessageBox]::Show("Backup folder does not exist.`n$backupFolder", "Error", 'OK', 'Error') | Out-Null
        return
    }
    $lastBackup = Get-ChildItem -Path $backupFolder -Directory | Sort-Object Name -Descending | Select-Object -First 1
    if (-not $lastBackup) {
        [System.Windows.Forms.MessageBox]::Show("No backup folders found in:`n$backupFolder", "Info", 'OK', 'Information') | Out-Null
        return
    }
    try {
        Get-ChildItem -Path $lastBackup.FullName -Filter "core_user_*.dat" | ForEach-Object {
            Copy-Item $_.FullName -Destination $scriptFolder -Force
            $destFile = Join-Path $scriptFolder $_.Name
            (Get-Item $destFile).LastWriteTime = Get-Date
            (Get-Item $destFile).CreationTime = Get-Date
        }
        Get-ChildItem -Path $lastBackup.FullName -Filter "core_char_*.dat" | ForEach-Object {
            Copy-Item $_.FullName -Destination $scriptFolder -Force
            $destFile = Join-Path $scriptFolder $_.Name
            (Get-Item $destFile).LastWriteTime = Get-Date
            (Get-Item $destFile).CreationTime = Get-Date
        }
        [System.Windows.Forms.MessageBox]::Show("Backup restored from last local backup.", "Success", 'OK', 'Information') | Out-Null
    }
    catch {
        [System.Windows.Forms.MessageBox]::Show("Error during restore:`n$_", "Error", 'OK', 'Error') | Out-Null
    }
}

# --- Clear All UI Settings ---
function ClearAllUISettings {
    $filesToDelete = Get-ChildItem -Path $scriptFolder -Filter "core_user_*.dat" -ErrorAction SilentlyContinue
    $filesToDelete += Get-ChildItem -Path $scriptFolder -Filter "core_char_*.dat" -ErrorAction SilentlyContinue
    if ($filesToDelete.Count -eq 0) {
        [System.Windows.Forms.MessageBox]::Show("No UI files found to delete.", "Info", 'OK', 'Information') | Out-Null
        return
    }
    $confirm = [System.Windows.Forms.MessageBox]::Show("Are you sure you want to delete all UI settings?", "Confirm Delete", [System.Windows.Forms.MessageBoxButtons]::YesNo, [System.Windows.Forms.MessageBoxIcon]::Warning)
    if ($confirm -eq [System.Windows.Forms.DialogResult]::Yes) {
        try {
            $filesToDelete | Remove-Item -Force
            [System.Windows.Forms.MessageBox]::Show("All UI settings deleted.", "Success", 'OK', 'Information') | Out-Null
        }
        catch {
            [System.Windows.Forms.MessageBox]::Show("Error deleting files:`n$_", "Error", 'OK', 'Error') | Out-Null
        }
    }
}

# --- Save last BackupUI to USB ---
function SaveBackupToUSB {
    $usb = Get-USBDrive
    if (-not $usb) { return }

    if (-not (Test-Path $backupFolder)) {
        [System.Windows.Forms.MessageBox]::Show("BackupUI folder not found:`n$backupFolder", "Error", 'OK', 'Error') | Out-Null
        return
    }
    $lastBackup = Get-ChildItem -Path $backupFolder -Directory | Sort-Object Name -Descending | Select-Object -First 1
    if (-not $lastBackup) {
        [System.Windows.Forms.MessageBox]::Show("No backup found in:`n$backupFolder", "Error", 'OK', 'Error') | Out-Null
        return
    }

    $dest = Join-Path $usb "EVE_UI_Backup"
    if (!(Test-Path $dest)) { New-Item -ItemType Directory -Path $dest | Out-Null }

    try {
        $filesToCopyUser = Get-ChildItem -Path $lastBackup.FullName -Filter "core_user_*.dat"
        $filesToCopyChar = Get-ChildItem -Path $lastBackup.FullName -Filter "core_char_*.dat"

        if (($filesToCopyUser.Count + $filesToCopyChar.Count) -eq 0) {
            [System.Windows.Forms.MessageBox]::Show("No files to copy from backup.", "Error", 'OK', 'Error') | Out-Null
            return
        }

        foreach ($f in $filesToCopyUser + $filesToCopyChar) {
            Copy-Item -Path $f.FullName -Destination $dest -Force
        }
        [System.Windows.Forms.MessageBox]::Show("Last backup saved to USB.", "Success", 'OK', 'Information') | Out-Null
    }
    catch {
        [System.Windows.Forms.MessageBox]::Show("Error saving to USB:`n$_", "Error", 'OK', 'Error') | Out-Null
    }
}

# --- Load backup from USB ---
function LoadBackupFromUSB {
    $usb = Get-USBDrive
    if (-not $usb) { return }

    $src = Join-Path $usb "EVE_UI_Backup"
    if (!(Test-Path $src)) {
        [System.Windows.Forms.MessageBox]::Show("Backup folder not found on USB:`n$src", "Error", 'OK', 'Error') | Out-Null
        return
    }

    try {
        $filesToCopyUser = Get-ChildItem -Path $src -Filter "core_user_*.dat"
        $filesToCopyChar = Get-ChildItem -Path $src -Filter "core_char_*.dat"

        if (($filesToCopyUser.Count + $filesToCopyChar.Count) -eq 0) {
            [System.Windows.Forms.MessageBox]::Show("No backup files found on USB.", "Error", 'OK', 'Error') | Out-Null
            return
        }

        # Copy to active folder and update timestamps
        foreach ($f in $filesToCopyUser + $filesToCopyChar) {
            Copy-Item -Path $f.FullName -Destination $scriptFolder -Force
            $destFile = Join-Path $scriptFolder $f.Name
            (Get-Item $destFile).LastWriteTime = Get-Date
            (Get-Item $destFile).CreationTime = Get-Date
        }

        # Save a new backup in local BackupUI folder with timestamp
        $timestamp = Get-Date -Format "yyyy-MM-dd_HH-mm-ss"
        $backupFolderFull = Join-Path $backupFolder $timestamp
        New-Item -Path $backupFolderFull -ItemType Directory -Force | Out-Null

        foreach ($f in $filesToCopyUser + $filesToCopyChar) {
            Copy-Item -Path $f.FullName -Destination $backupFolderFull -Force
            $backupFile = Join-Path $backupFolderFull $f.Name
            (Get-Item $backupFile).LastWriteTime = Get-Date
            (Get-Item $backupFile).CreationTime = Get-Date
        }

        [System.Windows.Forms.MessageBox]::Show("Backup restored from USB and saved locally.", "Success", 'OK', 'Information') | Out-Null
    }
    catch {
        [System.Windows.Forms.MessageBox]::Show("Error loading from USB:`n$_", "Error", 'OK', 'Error') | Out-Null
    }
}

# --- GUI setup ---

$form = New-Object System.Windows.Forms.Form
$form.Text = "EVE UI Manager"
$form.Size = New-Object System.Drawing.Size(340, 310)
$form.StartPosition = "CenterScreen"
$form.FormBorderStyle = 'FixedDialog'
$form.MaximizeBox = $false
$form.MinimizeBox = $false
$form.BackColor = [System.Drawing.SystemColors]::Control
$form.Font = New-Object System.Drawing.Font("MS Sans Serif", 9)

function CreateWin98Button {
    param($text, $x, $y, $clickAction)
    $btn = New-Object System.Windows.Forms.Button
    $btn.Text = $text
    $btn.Location = New-Object System.Drawing.Point($x, $y)
    $btn.Size = New-Object System.Drawing.Size(270, 35)
    $btn.BackColor = [System.Drawing.SystemColors]::Control
    $btn.ForeColor = [System.Drawing.SystemColors]::ControlText
    $btn.FlatStyle = 'Standard'
    $btn.Font = New-Object System.Drawing.Font("MS Sans Serif", 9)
    $btn.Add_Click($clickAction)
    return $btn
}

$btnSaveLocal = CreateWin98Button "Save Current UI to All" 30 20 { SaveCurrentUIToAll }
$form.Controls.Add($btnSaveLocal)

$btnRestoreLocal = CreateWin98Button "Restore from Last BackupUI" 30 65 { RestoreFromLastBackup }
$form.Controls.Add($btnRestoreLocal)

$btnSaveUSB = CreateWin98Button "Save Last BackupUI to USB" 30 110 { SaveBackupToUSB }
$form.Controls.Add($btnSaveUSB)

$btnLoadUSB = CreateWin98Button "Load BackupUI from USB" 30 155 { LoadBackupFromUSB }
$form.Controls.Add($btnLoadUSB)

$btnClearLocal = CreateWin98Button "Clear All UI Settings" 30 200 { ClearAllUISettings }
$btnClearLocal.ForeColor = [System.Drawing.Color]::FromArgb(128, 0, 0)
$form.Controls.Add($btnClearLocal)

# Zobraz okno
$form.Topmost = $true
[void]$form.ShowDialog()
